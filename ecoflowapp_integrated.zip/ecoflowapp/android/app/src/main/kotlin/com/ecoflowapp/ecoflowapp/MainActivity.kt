package com.ecoflowapp.ecoflowapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
